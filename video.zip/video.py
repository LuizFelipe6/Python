from tkinter import *
from tkvideo import tkvideo
import pygame
root = Tk()
pygame.init()
root.title("video")
video_lable = Label(root)
video_lable.pack()
player = tkvideo('video\Woah Pipe Bomb (animated).mp4', video_lable,loop=False,size=(970,890))
pygame.mixer.music.load("video\Woah Pipe Bomb (animated)_IOy9SuAFkgY.mp3")
pygame.mixer.music.play()
player.play()
root.mainloop()